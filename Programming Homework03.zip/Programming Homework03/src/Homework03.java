import java.util.Scanner;

import static java.lang.Math.pow;
import static java.lang.Math.sqrt;


public class Homework03 {
    public static void main(String[]args){
        Scanner keyboard=new Scanner(System.in);
//        calculation the area of circle
        double radious;
        double PI=3.14;
        System.out.println("please enter the volue for radious:");
        radious=keyboard.nextDouble();
        double area=3.14*radious*radious;
        System.out.println("the volue for area is "+area);
        area=keyboard.nextDouble();
//        calculate the perimeter of circle
        double radious1;
        System.out.println("please enter the volue for radious");
        radious1=keyboard.nextDouble();
        double perimeterofcircle=2*3.14*radious1;
        System.out.println("the volue for perimeter is"+perimeterofcircle);
        perimeterofcircle=keyboard.nextDouble();
//        calculation the area of triangle
        double  height,base;
        System.out.println("please enter the volue for height");
        height=keyboard.nextInt();
        System.out.println("please enter the volue for base");
        base=keyboard.nextInt();
        double areaoftriangle=0.5*base*height;
        System.out.println("the volue for triangle is "+areaoftriangle);
        areaoftriangle=keyboard.nextDouble();
//        calulate the area of rectangle
        double lenght,weight;
        System.out.println("please enter volue for lenght");
        lenght=keyboard.nextDouble();
        System.out.println("please enter the volue for weight");
        weight=keyboard.nextDouble();
        double areaofrectangle=weight*lenght;
        System.out.println("the volue for area of rectangle is "+areaofrectangle);
//calculation of volume of acylinder
        double heightC,radiousC;
        System.out.println("please enter the volue of heightC :");
        heightC=keyboard.nextDouble();
        System.out.println("please enter the volue for radiousC");
        radiousC=keyboard.nextDouble();
        double volumeofcylinder=3.14*radiousC*radiousC*heightC;
        System.out.println("the volume of cylinder is "+volumeofcylinder);
//calculate the area of parallelogram
        int baseP,heightP;
        System.out.println("please enter the volue for baseP ");
baseP=keyboard.nextInt();
        System.out.println("please enter volue for heightP ");
        heightP=keyboard.nextInt();
        int areaPA=heightP*baseP;
        System.out.println("the volue is "+areaPA);
//        converting from celsious to fahrenhiet;
        int celsious;
        System.out.println("please enter the volue for celsious");
        celsious=keyboard.nextInt();
        int fahrenhiet=((celsious*9)/5)+32;
        System.out.println("the volue for fahrenhite is "+fahrenhiet);
//        calculate the simple interst;
        int principle,rate,time;
        System.out.println("please enter the volue for principle");
        principle=keyboard.nextInt();
        System.out.println("please enter the volue for rate");
        rate=keyboard.nextInt();
        System.out.println("please enter the volue for time");
        time=keyboard.nextInt();
        int simpleinterst=principle*rate*time;
        System.out.println("the simole interst is "+simpleinterst);
//        calculate the surface area of sphere
        double radiousS;
        System.out.println("please enter the volue for radiousS ");
    radiousS=keyboard.nextInt();
    double surfaceareaofsphere=4*3.14*radiousS*radiousS;
        System.out.println("the volue is "+surfaceareaofsphere);
//        calculate the volume of sphere
        double radiousSP;
        System.out.println("please enter the volue for radiousSp");
        radiousSP=keyboard.nextInt();
        double volumeofsphere=(4/3)*3.14*radiousSP*radiousSP;
        System.out.println("the volume is "+volumeofsphere);
//calculation the area of trapezoid
        double leinght1,leinght2,heightT;
        System.out.println("please enter the volue for leinght1");
        leinght1=keyboard.nextInt();
        System.out.println("please enter the volue for leinght2");
        leinght2=keyboard.nextInt();
        System.out.println("please enter the volue for height");
        heightT=keyboard.nextInt();
        double area_T=0.5*(leinght1+leinght2)*heightT;
        System.out.println("the area is "+area_T);
//        calculate the perimeter of a triangle
        int numberA,numberB,numberC;
        System.out.println("please enter the volue for numberA");
        numberA=keyboard.nextInt();
        System.out.println("please enter the volue for numberB");
        numberB=keyboard.nextInt();
        System.out.println("please enter the volue for numberC");
        numberC=keyboard.nextInt();
        int perimeter_triangle=numberA+numberB+numberC;
        System.out.println("the volue is "+perimeter_triangle);
//        calculate the quadratic function
        double a,b,c;
        System.out.println("please enter the volue for a");
        a=keyboard.nextInt();
        System.out.println("please enter the volue for b");
        b=keyboard.nextInt();
        System.out.println("please enter the volue for c");
        c=keyboard.nextInt();
        double x=(-b+sqrt(b*b-4*a*c))/2*a;
        double y=(-b-sqrt(b*b-4*a*c))/2*a;
        System.out.println("the volue for x is "+x);
        System.out.println("the vplue for y is "+y);
//        calculate the distance between two places
        double x1,x2,y1,y2;
        System.out.println("please enter the volue for x1");
        x1=keyboard.nextDouble();
        System.out.println("please enter the volue for x2");
        x2=keyboard.nextDouble();
        System.out.println("please enter the volue for y1");
        y1=keyboard.nextDouble();
        System.out.println("please enter the volue for y2");
        y2=keyboard.nextDouble();
        double D=sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
        System.out.println("the distance is "+D);
//        convert the km to mile
        double kilometer;
        System.out.println("please enter the volue for kilometer ");
        kilometer=keyboard.nextDouble();
        double convarsionfactor=0.621371;
        convarsionfactor=keyboard.nextDouble();
        double mile=kilometer*convarsionfactor;
        System.out.println("the volue for mile is "+mile);









    }

    private static double pow(int i) {
    }


}
